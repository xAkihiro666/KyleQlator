#pragma once

namespace Harder {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^ panel1;

	private: System::Windows::Forms::TextBox^ tSpent;


	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ tBudget;

	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ Submit;



	private: System::Windows::Forms::Panel^ panel2;
	private: System::Windows::Forms::Button^ Reset;

	private: System::Windows::Forms::Label^ dIncome;

	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ dDays;

	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Days;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^ Savings;




	protected:

	protected:







	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->Reset = (gcnew System::Windows::Forms::Button());
			this->Submit = (gcnew System::Windows::Forms::Button());
			this->tSpent = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->tBudget = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->panel2 = (gcnew System::Windows::Forms::Panel());
			this->dIncome = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->dDays = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->Days = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Savings = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->panel1->SuspendLayout();
			this->panel2->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(35)), static_cast<System::Int32>(static_cast<System::Byte>(37)),
				static_cast<System::Int32>(static_cast<System::Byte>(49)));
			this->panel1->Controls->Add(this->Reset);
			this->panel1->Controls->Add(this->Submit);
			this->panel1->Controls->Add(this->tSpent);
			this->panel1->Controls->Add(this->label3);
			this->panel1->Controls->Add(this->tBudget);
			this->panel1->Controls->Add(this->label2);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Left;
			this->panel1->Font = (gcnew System::Drawing::Font(L"Satoshi", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->panel1->Location = System::Drawing::Point(0, 0);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(138, 364);
			this->panel1->TabIndex = 0;
			// 
			// Reset
			// 
			this->Reset->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(241)), static_cast<System::Int32>(static_cast<System::Byte>(91)),
				static_cast<System::Int32>(static_cast<System::Byte>(70)));
			this->Reset->FlatAppearance->BorderSize = 0;
			this->Reset->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Reset->ForeColor = System::Drawing::Color::White;
			this->Reset->Location = System::Drawing::Point(26, 329);
			this->Reset->Name = L"Reset";
			this->Reset->Size = System::Drawing::Size(75, 23);
			this->Reset->TabIndex = 9;
			this->Reset->Text = L"Reset";
			this->Reset->UseVisualStyleBackColor = false;
			// 
			// Submit
			// 
			this->Submit->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(25)), static_cast<System::Int32>(static_cast<System::Byte>(26)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->Submit->FlatAppearance->BorderSize = 0;
			this->Submit->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Submit->ForeColor = System::Drawing::Color::White;
			this->Submit->Location = System::Drawing::Point(26, 142);
			this->Submit->Name = L"Submit";
			this->Submit->Size = System::Drawing::Size(75, 23);
			this->Submit->TabIndex = 8;
			this->Submit->Text = L"Submit";
			this->Submit->UseVisualStyleBackColor = false;
			this->Submit->Click += gcnew System::EventHandler(this, &MyForm::Submit_Click);
			// 
			// tSpent
			// 
			this->tSpent->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tSpent->Location = System::Drawing::Point(12, 108);
			this->tSpent->Name = L"tSpent";
			this->tSpent->Size = System::Drawing::Size(106, 18);
			this->tSpent->TabIndex = 4;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->ForeColor = System::Drawing::Color::White;
			this->label3->Location = System::Drawing::Point(9, 79);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(40, 16);
			this->label3->TabIndex = 3;
			this->label3->Text = L"Spent";
			// 
			// tBudget
			// 
			this->tBudget->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->tBudget->Location = System::Drawing::Point(12, 43);
			this->tBudget->Name = L"tBudget";
			this->tBudget->Size = System::Drawing::Size(106, 18);
			this->tBudget->TabIndex = 2;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->ForeColor = System::Drawing::Color::White;
			this->label2->Location = System::Drawing::Point(9, 14);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(49, 16);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Budget";
			// 
			// panel2
			// 
			this->panel2->AutoScroll = true;
			this->panel2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(25)), static_cast<System::Int32>(static_cast<System::Byte>(26)),
				static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->panel2->Controls->Add(this->dataGridView1);
			this->panel2->Controls->Add(this->dIncome);
			this->panel2->Controls->Add(this->label6);
			this->panel2->Controls->Add(this->dDays);
			this->panel2->Controls->Add(this->label5);
			this->panel2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel2->Location = System::Drawing::Point(138, 0);
			this->panel2->Name = L"panel2";
			this->panel2->Size = System::Drawing::Size(675, 364);
			this->panel2->TabIndex = 1;
			// 
			// dIncome
			// 
			this->dIncome->AutoSize = true;
			this->dIncome->Font = (gcnew System::Drawing::Font(L"Satoshi", 9.75F));
			this->dIncome->ForeColor = System::Drawing::Color::White;
			this->dIncome->Location = System::Drawing::Point(145, 9);
			this->dIncome->Name = L"dIncome";
			this->dIncome->Size = System::Drawing::Size(16, 16);
			this->dIncome->TabIndex = 13;
			this->dIncome->Text = L"0";
			// 
			// label6
			// 
			this->label6->Font = (gcnew System::Drawing::Font(L"Satoshi", 9.75F));
			this->label6->ForeColor = System::Drawing::Color::White;
			this->label6->Location = System::Drawing::Point(89, 9);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(67, 16);
			this->label6->TabIndex = 12;
			this->label6->Text = L"Income:";
			// 
			// dDays
			// 
			this->dDays->AutoSize = true;
			this->dDays->Font = (gcnew System::Drawing::Font(L"Satoshi", 9.75F));
			this->dDays->ForeColor = System::Drawing::Color::White;
			this->dDays->Location = System::Drawing::Point(47, 9);
			this->dDays->Name = L"dDays";
			this->dDays->Size = System::Drawing::Size(11, 16);
			this->dDays->TabIndex = 11;
			this->dDays->Text = L"1";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Satoshi", 9.75F));
			this->label5->ForeColor = System::Drawing::Color::White;
			this->label5->Location = System::Drawing::Point(6, 9);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(39, 16);
			this->label5->TabIndex = 10;
			this->label5->Text = L"Days:";
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(25)),
				static_cast<System::Int32>(static_cast<System::Byte>(26)), static_cast<System::Int32>(static_cast<System::Byte>(35)));
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) { this->Days, this->Savings });
			this->dataGridView1->Location = System::Drawing::Point(9, 43);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersWidthSizeMode = System::Windows::Forms::DataGridViewRowHeadersWidthSizeMode::DisableResizing;
			this->dataGridView1->Size = System::Drawing::Size(654, 309);
			this->dataGridView1->TabIndex = 14;
			// 
			// Days
			// 
			this->Days->HeaderText = L"Days";
			this->Days->Name = L"Days";
			this->Days->ReadOnly = true;
			// 
			// Savings
			// 
			this->Savings->HeaderText = L"Savings";
			this->Savings->Name = L"Savings";
			this->Savings->ReadOnly = true;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(813, 364);
			this->Controls->Add(this->panel2);
			this->Controls->Add(this->panel1);
			this->MaximizeBox = false;
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->panel1->ResumeLayout(false);
			this->panel1->PerformLayout();
			this->panel2->ResumeLayout(false);
			this->panel2->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {

	}

	private: System::Void Submit_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ spentInput = tSpent->Text;
		String^ budgetInput = tBudget->Text;

		try {
			int tSpent = System::Int32::Parse(spentInput);
			int tBudget = System::Int32::Parse(budgetInput);

			if (tSpent > tBudget) {
				MessageBox::Show("Expense exceeds budget!", "Error");
			}
		}
		catch (FormatException^) {
			MessageBox::Show("Please enter valid integer values.", "Error");
		}
	}
};
}
